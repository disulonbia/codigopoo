#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int a;
    int b;
    cin >> a;
    cin >> b;
    int S = a + b;
    int P = a *b;
	cout << "a+b=" << S << "\n";
    cout << "a*b=" << P << "\n";
	return 0;
}
